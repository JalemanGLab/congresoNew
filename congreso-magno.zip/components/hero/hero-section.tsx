"use client"

import EventSlider from "./event-slider"

export default function HeroSection() {
  return (
    <section id="inicio" className="relative">
      <EventSlider />
    </section>
  )
}

